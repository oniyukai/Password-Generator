#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
using namespace std;
int main()
{
    cout << "--------------------" << endl << "�K�X�ͦ��� Version 2.0_2022.04.02" << endl << "Made By YU KAI" << endl << "--------------------" << endl << endl;
    while(true)
    {
        int n;
        cout << "��J�K�X������:";
        cin >> n;
        srand(time(0));
        int groups;
        cout << "��J�ͦ��X�ձK�X:";
        cin >> groups;
        string alphanum("");
        string character[]={"0123456789","abcdefghijklmnopqrstuvwxyz","ABCDEFGHIJKLMNOPQRSTUVWXYZ","!@#$\%^&*"};
        string announcement[]={"�O�_�n�[�J1-9�H [Y/N] ","�O�_�n�[�Ja-z�H [Y/N] ","�O�_�n�[�JA-Z�H [Y/N] ","�O�_�n�[�J�u!@#$\%^&*�v�H [Y/N] "};
        char answer;
        for(int j=0;j<4;j++)
        {
            cout << announcement[j];
            cin >> answer;
            if (answer == 'Y' or answer == 'y')
                alphanum += character[j];
        }
        cout << "�O�_�n�ӥ~��J�r�šH [Y/N] ";
        cin >> answer;
        if (answer == 'Y' or answer == 'y')
        {
            string add;
            cout << "��J�ӥ~�r��:" << endl;
            cin >> add;
            alphanum += add;
        }
        int string_length = alphanum.length() -1;
        cout << "�ͦ����K�X:" << endl;
        for (groups; groups>0; groups--)
        {
            for (int i = 0; i < n; i++)
                cout << alphanum[rand() % string_length];
            cout << endl;
        }
        cout << endl;
    }
    return 0;
}
